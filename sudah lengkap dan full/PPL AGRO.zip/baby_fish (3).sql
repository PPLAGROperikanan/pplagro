-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Feb 12, 2016 at 03:16 AM
-- Server version: 10.1.17-MariaDB-1~trusty
-- PHP Version: 5.6.23-1+deprecated+dontuse+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baby_fish`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_benih`
--

CREATE TABLE `tb_benih` (
  `id_benih` int(11) NOT NULL,
  `golongan` varchar(20) NOT NULL,
  `jumlah_benih` int(11) NOT NULL,
  `tanggal_input` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_benih`
--

INSERT INTO `tb_benih` (`id_benih`, `golongan`, `jumlah_benih`, `tanggal_input`) VALUES
(1, 'Golongan 1', 200, '2016-12-04'),
(2, 'Golongan 2', 250, '2016-12-04'),
(5, 'Golongan 2', 110, '2016-02-12');

-- --------------------------------------------------------

--
-- Table structure for table `tb_induk`
--

CREATE TABLE `tb_induk` (
  `id_induk` int(11) NOT NULL,
  `id_kolam` int(11) NOT NULL,
  `jumlah_induk` int(11) NOT NULL,
  `berat_rata` double NOT NULL,
  `tanggal_induk` date NOT NULL,
  `status_induk` enum('Aktif','Tidak aktif','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_induk`
--

INSERT INTO `tb_induk` (`id_induk`, `id_kolam`, `jumlah_induk`, `berat_rata`, `tanggal_induk`, `status_induk`) VALUES
(1, 1, 12, 12, '2016-10-25', 'Tidak aktif'),
(2, 2, 121, 12, '2016-10-26', 'Tidak aktif'),
(3, 3, 200, 15, '2016-10-26', 'Tidak aktif'),
(4, 6, 50, 10, '2016-10-26', 'Tidak aktif'),
(5, 5, 40, 10, '2016-10-26', 'Tidak aktif'),
(6, 2, 100, 15, '2016-10-26', 'Aktif'),
(7, 3, 150, 14, '2016-10-29', 'Aktif'),
(8, 4, 200, 10, '2016-10-28', 'Tidak aktif'),
(9, 1, 12, 12, '2016-10-28', 'Aktif'),
(10, 2, 111, 111, '2016-02-12', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori_keasaman`
--

CREATE TABLE `tb_kategori_keasaman` (
  `id_kategori_keasaman` int(11) NOT NULL,
  `ukuran_keasaman` varchar(10) NOT NULL,
  `status` text NOT NULL,
  `tindakan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori_keasaman`
--

INSERT INTO `tb_kategori_keasaman` (`id_kategori_keasaman`, `ukuran_keasaman`, `status`, `tindakan`) VALUES
(1, '6.5 - 8', 'Normal', 'Tidak ada tindakan'),
(2, '9 - 14', 'Basah', 'Lakukan pembuangan / penggantian air'),
(3, '5.1 - 6.4', 'Asam Medium', 'Lakukan pemberian kapur pertanian CaCO3 sebanyak 250 – 499 kg/Ha.'),
(4, '4 - 5', 'Asam Tinggi', 'Lakukan pemberian Dolomit CaMg(CO3)2 sebanyak 500 – 1000 kg/Ha.');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori_pencemaran`
--

CREATE TABLE `tb_kategori_pencemaran` (
  `id_kategori_pencemaran` int(11) NOT NULL,
  `jenis_kategori_pencemaran` varchar(30) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori_pencemaran`
--

INSERT INTO `tb_kategori_pencemaran` (`id_kategori_pencemaran`, `jenis_kategori_pencemaran`, `keterangan`) VALUES
(1, 'Fisika', 'Bersihkan sampah yang terdapat pada kolam tersebut'),
(2, 'Biologi < 50', 'Kolam masih dalam kondisi aman'),
(3, 'Biologi > 50', 'Silahkan lakukan pengurasan kolam'),
(4, 'Kimia', 'Silahkan melakukan pemindahan ikan ke kolam lain');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori_suhu`
--

CREATE TABLE `tb_kategori_suhu` (
  `id_kategori_suhu` int(11) NOT NULL,
  `jenis_kategori_suhu` varchar(25) NOT NULL,
  `ukuran_suhu` varchar(30) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori_suhu`
--

INSERT INTO `tb_kategori_suhu` (`id_kategori_suhu`, `jenis_kategori_suhu`, `ukuran_suhu`, `keterangan`) VALUES
(1, 'normal', '25 - 30', 'Kondisi air normal'),
(2, 'panas', '29 - 37', 'Kondisi air terlalu panas'),
(3, 'dingin', '16 - 24', 'Kondisi air terlalu dingin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelola_kolam`
--

CREATE TABLE `tb_kelola_kolam` (
  `id_kelola_kolam` int(11) NOT NULL,
  `tanggal_kelola` date NOT NULL,
  `id_kolam` int(11) NOT NULL,
  `jenis_kelola` enum('suhu','keasaman','pencemaran','irigasi') NOT NULL,
  `id_kategori_suhu` int(11) DEFAULT NULL,
  `id_kategori_keasaman` int(11) DEFAULT NULL,
  `id_kategori_pencemaran` int(11) DEFAULT NULL,
  `permasalahan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kelola_kolam`
--

INSERT INTO `tb_kelola_kolam` (`id_kelola_kolam`, `tanggal_kelola`, `id_kolam`, `jenis_kelola`, `id_kategori_suhu`, `id_kategori_keasaman`, `id_kategori_pencemaran`, `permasalahan`) VALUES
(1, '2016-12-04', 1, 'irigasi', NULL, NULL, NULL, NULL),
(2, '2016-12-04', 3, 'irigasi', NULL, NULL, NULL, NULL),
(3, '2016-12-04', 3, 'irigasi', NULL, NULL, NULL, NULL),
(4, '2016-12-05', 2, 'keasaman', NULL, 4, NULL, '4.5'),
(5, '2016-12-05', 6, 'keasaman', NULL, 2, NULL, '10'),
(6, '2016-12-05', 5, 'keasaman', NULL, 2, NULL, '10'),
(7, '2016-12-05', 3, 'keasaman', NULL, 4, NULL, '5'),
(8, '2016-12-05', 1, 'keasaman', NULL, 4, NULL, '5'),
(9, '2016-12-11', 4, 'irigasi', NULL, NULL, NULL, NULL),
(10, '2016-12-11', 3, 'suhu', 1, NULL, NULL, '27'),
(11, '2016-12-11', 5, 'suhu', 1, NULL, NULL, '26'),
(12, '2016-12-11', 4, 'suhu', 2, NULL, NULL, '30'),
(13, '2016-12-11', 2, 'suhu', 3, NULL, NULL, '20'),
(14, '2016-12-11', 5, 'suhu', 1, NULL, NULL, '28'),
(15, '2016-12-11', 5, 'suhu', 2, NULL, NULL, '31'),
(16, '2016-12-12', 2, 'pencemaran', NULL, NULL, 1, 'Banyak sampah'),
(17, '2016-12-12', 5, 'pencemaran', NULL, NULL, 3, 'Banyak Pestisida'),
(18, '2016-12-12', 5, 'pencemaran', NULL, NULL, 3, 'Banyak detergen'),
(19, '2016-12-12', 1, 'pencemaran', NULL, NULL, 3, 'Banyak eek'),
(20, '2016-12-12', 1, 'pencemaran', NULL, NULL, 3, 'Banyak pakan mngendap'),
(21, '2016-12-12', 3, 'pencemaran', NULL, NULL, 1, 'Banyak sampah'),
(22, '2016-12-12', 3, 'pencemaran', NULL, NULL, 1, 'Banyak Sampah'),
(23, '2016-12-12', 3, 'pencemaran', NULL, NULL, 1, 'Banyak Sampah'),
(24, '2016-12-12', 2, 'pencemaran', NULL, NULL, 3, 'Banyak racun'),
(25, '2016-12-12', 5, 'pencemaran', NULL, NULL, 3, 'Banyak detergen'),
(26, '2016-12-12', 4, 'pencemaran', NULL, NULL, 1, 'Banyak sampah'),
(27, '2016-12-12', 2, 'pencemaran', NULL, NULL, 1, 'Banyak Sampah'),
(28, '2016-12-12', 2, 'pencemaran', NULL, NULL, 1, 'Banyak sampah'),
(29, '2016-12-12', 2, 'pencemaran', NULL, NULL, 1, ''),
(30, '2016-12-12', 3, 'keasaman', NULL, 4, NULL, '5'),
(31, '2016-12-12', 3, 'suhu', 2, NULL, NULL, NULL),
(32, '2016-12-12', 4, 'suhu', 2, NULL, NULL, NULL),
(33, '2016-12-12', 1, 'suhu', 3, NULL, NULL, NULL),
(34, '2016-12-12', 2, 'suhu', 1, NULL, NULL, NULL),
(35, '2016-12-12', 3, 'pencemaran', NULL, NULL, 1, 'sampah'),
(36, '2016-12-12', 4, 'pencemaran', NULL, NULL, 1, 'Plastik'),
(37, '2016-12-12', 5, 'pencemaran', NULL, NULL, 3, 'Pestisida'),
(38, '2016-12-12', 1, 'pencemaran', NULL, NULL, 0, ''),
(39, '2016-02-12', 3, 'pencemaran', NULL, NULL, 2, 'Jumlah plankton 50%. banyak plankston bos'),
(40, '2016-02-12', 1, 'pencemaran', NULL, NULL, 2, 'Jumlah plankton 90%. Percobaan'),
(41, '2016-02-12', 1, 'pencemaran', NULL, NULL, 2, 'Jumlah plankton 90%. Banyak');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kolam`
--

CREATE TABLE `tb_kolam` (
  `id_kolam` int(11) NOT NULL,
  `nama_kolam` varchar(10) NOT NULL,
  `panjang kolam` double NOT NULL,
  `lebar kolam` double NOT NULL,
  `tinggi_kolam` double NOT NULL,
  `volume` double NOT NULL,
  `daya_tampung_maksimal` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kolam`
--

INSERT INTO `tb_kolam` (`id_kolam`, `nama_kolam`, `panjang kolam`, `lebar kolam`, `tinggi_kolam`, `volume`, `daya_tampung_maksimal`) VALUES
(1, 'Kolam 1', 20, 10, 2, 400, 200),
(2, 'Kolam 2', 40, 10, 2, 800, 250),
(3, 'Kolam 3', 10, 10, 2, 200, 50),
(4, 'Kolam 4', 20, 10, 2, 400, 100),
(5, 'Kolam 5', 20, 20, 2, 800, 150),
(6, 'Kolam 6', 20, 50, 2, 2000, 200);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pakan`
--

CREATE TABLE `tb_pakan` (
  `id_pakan` int(5) NOT NULL,
  `id_kolam` int(1) NOT NULL,
  `tanggal` date NOT NULL,
  `berat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pakan`
--

INSERT INTO `tb_pakan` (`id_pakan`, `id_kolam`, `tanggal`, `berat`) VALUES
(1, 2, '2016-11-14', '12 kg'),
(2, 1, '2016-12-02', '15 kg'),
(3, 3, '2016-12-05', '10 kg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(1) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `status`) VALUES
(1, 'pengelola', 'pengelola', 'Pengelola'),
(2, 'gudang', 'gudang', 'Gudang'),
(3, 'kepala', 'kepala', 'Kepala'),
(4, 'pakan', 'pakan', 'Pakan'),
(5, 'display', 'display', 'Display');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_benih`
--
ALTER TABLE `tb_benih`
  ADD PRIMARY KEY (`id_benih`);

--
-- Indexes for table `tb_induk`
--
ALTER TABLE `tb_induk`
  ADD PRIMARY KEY (`id_induk`);

--
-- Indexes for table `tb_kategori_keasaman`
--
ALTER TABLE `tb_kategori_keasaman`
  ADD PRIMARY KEY (`id_kategori_keasaman`);

--
-- Indexes for table `tb_kategori_pencemaran`
--
ALTER TABLE `tb_kategori_pencemaran`
  ADD PRIMARY KEY (`id_kategori_pencemaran`);

--
-- Indexes for table `tb_kategori_suhu`
--
ALTER TABLE `tb_kategori_suhu`
  ADD PRIMARY KEY (`id_kategori_suhu`);

--
-- Indexes for table `tb_kelola_kolam`
--
ALTER TABLE `tb_kelola_kolam`
  ADD PRIMARY KEY (`id_kelola_kolam`);

--
-- Indexes for table `tb_kolam`
--
ALTER TABLE `tb_kolam`
  ADD PRIMARY KEY (`id_kolam`);

--
-- Indexes for table `tb_pakan`
--
ALTER TABLE `tb_pakan`
  ADD PRIMARY KEY (`id_pakan`),
  ADD KEY `id_kolam` (`id_kolam`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_benih`
--
ALTER TABLE `tb_benih`
  MODIFY `id_benih` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tb_induk`
--
ALTER TABLE `tb_induk`
  MODIFY `id_induk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tb_kategori_pencemaran`
--
ALTER TABLE `tb_kategori_pencemaran`
  MODIFY `id_kategori_pencemaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_kelola_kolam`
--
ALTER TABLE `tb_kelola_kolam`
  MODIFY `id_kelola_kolam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `tb_kolam`
--
ALTER TABLE `tb_kolam`
  MODIFY `id_kolam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tb_pakan`
--
ALTER TABLE `tb_pakan`
  MODIFY `id_pakan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_pakan`
--
ALTER TABLE `tb_pakan`
  ADD CONSTRAINT `tb_pakan_ibfk_1` FOREIGN KEY (`id_kolam`) REFERENCES `tb_kolam` (`id_kolam`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
